from django.apps import AppConfig


class SoftProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'soft_project'
