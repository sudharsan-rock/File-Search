from django.shortcuts import render
from django.http import HttpResponse
import os
import PyPDF2
from docx import Document
import pandas as pd
# Create your views here.

def home_page(request):
    if request.method=='POST':
        path = request.POST.get('text')
        text = request.POST.get('content')
        l=find_files(path,text)
        return render(request,'soft_project/index.html',{'list':l})
    return render(request,template_name='soft_project/test.html')



def find_files(path,key):
    l=[]
    key=key.replace(" ","")
    print(path)
    if os.path.exists(path)==False:
        return "path is invalid"
    for i in os.listdir(path):
        print(i)
        if key.lower() in i.lower():
            print(i)
            l.append(i)
        filepath=path+'\\'+i
        print(filepath)
        if(os.path.isfile(filepath)):
            if '.txt' in filepath:
                file = open(filepath)
                for j in file:
                    j=j.replace(" ","")
                    if key.lower() in j.lower():
                        l.append(i)
                file.close()
            elif '.pdf' in filepath:
                print('pdf is read')
                p=PyPDF2.PdfFileReader(filepath)
                for j in range(0,p.numPages):
                    page=p.getPage(j)
                    t=page.extractText()
                    if key.lower() in t.lower():
                        l.append(i+'\nIn page no: '+str(j+1))
                        print(i)
            elif '.docx' in filepath:
                print(filepath)
                t = Document(filepath)
                for para in range(0,len(t.paragraphs)):
                    if key.lower() in t.paragraphs[para].text.lower():
                        l.append(i+'\nIn paragraph no: '+str(para+1))
            
            elif '.xlsx' in filepath:
                print('in here')
                f=pd.read_excel(filepath)
                c=list(f.columns)
                for j in c:
                    for k in range(0,len(list(f[c]))):
                        if key.lower() in str(f[j][k]):
                            l.append(i+'\nIn row number no: '+str(k+1))

                    
        else:
            for i in find_files(filepath,key):
                l.append(i)
    return l
    

