import PyPDF2
file=open("pdf1.pdf","rb")
p=PyPDF2.PdfFileReader("pdf1.pdf")

for i in range(0,p.numPages):
    page=p.getPage(i)
    print(page.extractText())
    
