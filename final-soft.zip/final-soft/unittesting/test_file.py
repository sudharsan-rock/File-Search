from dataclasses import replace
import os
import unittest
from pkg_resources import parse_requirements
import pytest
import textract

def find_files(path,key):
    l=[]
    key=key.replace(" ","")
    if os.path.exists(path)==False:
        return "path is invalid"
    for i in os.listdir(path):
        print(i)
        if key.lower() in i.lower():
            print(i)
            l.append(i)
        filepath=path+'\\'+i
        if(os.path.isfile(filepath)):
            file = textract.process(filepath)
            for j in file:
                j=j.replace(" ","")
                if key.lower() in j.lower():
                    l.append(i)
            file.close()
        else:
            for i in find_files(filepath,key):
                l.append(i)
    return l
key="pqr"
p="C:\\Users\\Sudharsan R\\Downloads\\soft-project-master\\soft-project-master\\Text files"
print(find_files(p,key))
class Testclass(unittest.TestCase):
    def test_function1(self):
        p="C:\\Users\\Sudharsan R\\Downloads\\soft-project-master\\soft-project-master\\invalidfolder"
        assert "path is invalid" ==find_files(p,"key")
    def test_function2(self):
        key="pqr"
        p="C:\\Users\\Sudharsan R\\Downloads\\soft-project-master\\soft-project-master\\Text files"
        assert ["srs.txt"]==find_files(p,key)
    def test_function3(self):
        key="abcd"
        p="C:\\Users\\Sudharsan R\\Downloads\\soft-project-master\\soft-project-master\\Text files"
        assert ["abc.txt"]==find_files(p,key)
    def test_function4(self):
        key="srs"
        p="C:\\Users\\Sudharsan R\\Downloads\\soft-project-master\\soft-project-master\\Text files"
        assert ["srs.txt"]==find_files(p,key)